package com.std.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.std.bean.StudentBean;
import com.std.service.IStudentService;

@Controller
public class StudentController {
@RequestMapping("home")
public String getHome()
{
	return "home";
}
@Autowired
private IStudentService sserv;
@RequestMapping("viewall")
public ModelAndView viewAll(){
	ModelAndView mv=new ModelAndView();
	//ArrayList<StudentBean> slist=sserv.getAllStudentInfo();
	ArrayList<StudentBean> slist=sserv.getAllStudentInfo();
	mv.setViewName("viewall");
	mv.addObject("data", slist);
	return mv;
}

}
