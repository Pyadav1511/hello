package com.std.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.std.bean.StudentBean;
import com.std.dao.IStudentDAO;
@Service
public class StudentServiceImpl implements IStudentService{

	@Autowired
	private IStudentDAO sdao;
	@Override
	public ArrayList<StudentBean> getAllStudentInfo() {
		
		return sdao.getAllStudentInfo();
	}
	

}
