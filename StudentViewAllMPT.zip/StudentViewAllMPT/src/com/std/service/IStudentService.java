package com.std.service;

import java.util.ArrayList;

import com.std.bean.StudentBean;

public interface IStudentService {

	public ArrayList<StudentBean> getAllStudentInfo();

}
