package com.std.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.std.bean.StudentBean;
@Repository
@Transactional
public class StudentDAOImpl implements IStudentDAO{

	@PersistenceContext
	private EntityManager em;
	@Override
	public ArrayList<StudentBean> getAllStudentInfo() {
         Query qry=em.createNamedQuery("getAllStudent");
		
		return (ArrayList<StudentBean>) qry.getResultList();
	}
	
}
