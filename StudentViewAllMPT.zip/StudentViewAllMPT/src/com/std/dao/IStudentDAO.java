package com.std.dao;

import java.util.ArrayList;

import com.std.bean.StudentBean;

public interface IStudentDAO {

	public ArrayList<StudentBean> getAllStudentInfo();

}
