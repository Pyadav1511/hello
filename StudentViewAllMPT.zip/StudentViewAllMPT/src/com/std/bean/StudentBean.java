package com.std.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="StudentBean")
@NamedQuery(name = "getAllStudent", query = "select s from StudentBean s")
public class StudentBean {
	@Id
	@Column(name="sId")
	private int sId;
	@Column(name="sName")
	private String sName;
	@Column(name="sMail")
	private String sMail;
	public StudentBean()
	{
		
	}
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsMail() {
		return sMail;
	}
	public void setsMail(String sMail) {
		this.sMail = sMail;
	}
	public StudentBean(int sId, String sName, String sMail) {

		this.sId = sId;
		this.sName = sName;
		this.sMail = sMail;
	}
	@Override
	public String toString() {
		return "Student Id:"+ this.sId +" "+this.sName+" "+this.sMail;
	}
	
	

}
