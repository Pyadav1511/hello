package exception;

public class PatientException extends Exception{

	public PatientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	

}
